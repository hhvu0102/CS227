package hw3;
import static api.CellState.MOVABLE_NEG;
import static api.CellState.MOVABLE_POS;
import static api.CellState.PEARL;
import static api.CellState.PORTAL;
import static api.CellState.isBoundary;
import static api.CellState.isMovable;

import java.util.ArrayList;
import java.util.Arrays;

import api.Cell;
import api.CellState;
import api.Descriptor;
import api.Direction;
import api.StringUtil;

/**
 * Basic game state and operations for a simplified version of the video game 
 * "Quell".
 */
public class CS227Quell
{
  /**
   * Two-dimensional array of Cell objects representing the 
   * grid on which the game is played.
   */
  private Cell[][] grid;
  
  /**
   * Instance of GameSupport to be used in the move() algorithm.
   */
  private GameSupport support;

  /**
   * The number of moves the player has taken.
   */
  private int numOfMoves;
  
  /**
   * The number of scores that the player has.
   */
  private int scores;
  
  /**
   * The number of pearls that are on the cell in the first place.
   */
  private int totalPearls;
  
  /**
   * The current row at the player is at.
   */
  private int currentRow;
  
  /**
   * The current column at the player is at.
   */
  private int currentCol;
  
  /**
   * Constructs a game from the given string description.  The conventions
   * for representing cell states as characters can be found in 
   * <code>StringUtil</code>.  
   * @param init
   *   string array describing initial cell states
   * @param support
   *   GameSupport instance to use in the <code>move</code> method
   */
  public CS227Quell(String[] init, GameSupport support)
  {
    grid = StringUtil.createFromStringArray(init);
    this.support = support;
    numOfMoves = 0;
    scores = 0;
    
	for (int row = 0; row < grid.length; row++)
	  {
		  for (int col = 0; col < grid[0].length; col++)
		  {
			  if (getCell(row, col).getState() == CellState.PEARL)
			  {
				  totalPearls += 1;
			  }
		  }
	  }
	
	currentRow = 0;
	currentCol = 0;
  }
  
  /**
   * Returns the number of columns in the grid.
   * @return
   *   width of the grid
   */
  public int getColumns()
  {
    return grid[0].length;
  }
  
  /**
   * Returns the number of rows in the grid.
   * @return
   *   height of the grid
   */
  public int getRows()
  {
    return grid.length;
  }
  
  /**
   * Returns the cell at the given row and column.
   * @param row
   *   row index for the cell
   * @param col
   *   column index for the cell
   * @return
   *   cell at given row and column
   */
  public Cell getCell(int row, int col)
  {
    return grid[row][col];
  }
  
  /**
   * Returns the row index for the player's current location.
   * @return
   * current row index for the player
   */
  public int getCurrentRow()
  {
	  for (int row = 0; row < grid.length; row++)
	  {
		  for (int col = 0; col < grid[0].length; col++)
		  {
			  if (getCell(row, col).isPlayerPresent())
			  {
				  currentRow = row;
			  }
		  }
	  }
	  return currentRow;
  }
  
  /**
   * Returns the column index for the player's current location.
   * @return
   * current column index for the player
   */
  public int getCurrentColumn()
  {
	  for (int row = 0; row < grid.length; row++)
	  {
		  for (int col = 0; col < grid[0].length; col++)
		  {
			  if (getCell(row, col).isPlayerPresent())
			  {
				  currentCol = col;
			  }
		  }
	  }
	  return currentCol;
  }
  
  /**
   * Returns true if the game is over, false otherwise.  The game ends when all pearls
   * are removed from the grid or when the player lands on a cell with spikes.
   * @return
   *   true if the game is over, false otherwise
   */
  public boolean isOver()
  {
	  return (countPearls() == 0 || landOnSpikes() == true);
  }
  
  /**
   * Returns true if the player has landed on spikes and hence dies
   * @return
   * true if the player has landed on spikes, false otherwise
   */
  private boolean landOnSpikes()
  {
	  boolean onSpikes = false;
	  if (grid[currentRow][currentCol].isPlayerPresent() == true && CellState.isSpikes(grid[currentRow][currentCol].getState()) == true)
	  {
		  onSpikes = true;
	  }
	  return onSpikes;
  }
  
  /**
   * Returns true if the game is over and the player did not die on spikes.
   * @return
   * true if the player wins, false otherwise
   */
  public boolean won()
  {
	  return (isOver() == true && landOnSpikes() == false);
  }
  
  /**
   * Returns the current number of moves made in this game.
   * @return
   * number of moves made
   */
  public int getMoves()
  {
	  return numOfMoves; 
  }
  
  /**
   * Returns the current score (number of pearls disappeared) for this game.
   * @return
   * current score
   */
  public int getScore()
  {
	  return scores;
  }

  
  /**
   * Performs a move along a cell sequence in the given direction, updating the score, 
   * the move count, and all affected cells in the grid.  The method returns an 
   * array of Descriptor objects representing the cells in original cell sequence before 
   * modification, with their <code>movedTo</code> and <code>disappeared</code>
   * status set to indicate the cells' new locations after modification.  
   * @param dir
   *   direction of the move
   * @return
   *   array of Descriptor objects describing modified cells
   */
  public Descriptor[] move(Direction dir)
  {
	  Cell[] cells = getCellSequence(dir);	  
	  int pearlsInCells = 0;
	  for (int i = 0; i < cells.length; i++)
	  {
		  if (cells[i].getState() == CellState.PEARL)
		  {
			  pearlsInCells += 1;
		  }
	  }
	  scores = scores + pearlsInCells;
	  
	  Descriptor[] descriptors = new Descriptor[cells.length];
	  for (int j = 0; j< cells.length; ++j)
	  {
		  descriptors[j] = new Descriptor(cells[j], j);
	  }
	  
	  support.shiftMovableBlocks(cells, descriptors);  
	  support.shiftPlayer(cells, descriptors, dir);
	  
	  setCellSequence(cells, dir);
	  
	  numOfMoves = numOfMoves + 1;
	  
    return descriptors;
  }
  
  
  /**
   * Finds a valid cell sequence in the given direction starting with the player's current position
   * and ending with a boundary cell as defined by the method CellState.isBoundary.
   * The actual cell locations are obtained by following getNextRow and getNextColumn in the given direction,
   * and the sequence ends when a boundary cell is found.
   * A boundary cell is defined by the CellState.isBoundary and is different depending on whether a movable block has been encountered so far in the cell sequence
   * (the player can move through open gates and portals, but the movable blocks cannot).
   * It can be assumed that there will eventually be a boundary cell (i.e., the grid has no infinite loops).
   * The first element of the returned array is the cell containing the player, and the last element of the array is the boundary cell.
   * This method does not modify the grid or any aspect of the game state.
   * @param dir
   * direction of the sequence
   * @return
   * array of cells in the cell sequence
   */
  public Cell[] getCellSequence(Direction dir)
  {
	  boolean doPortalJump = false;
	  ArrayList<Cell> cellSeq = new ArrayList<Cell>();
	  int row = getCurrentRow();
	  int col = getCurrentColumn();
	  Cell currentCell = getCell(row, col);
	  int numOfJumps = 0;
	  boolean movable = false;
	  while (CellState.isBoundary(currentCell.getState(), movable) == false)
	  {
		  cellSeq.add(currentCell);
		  if (currentCell.getState() == CellState.PORTAL)
		  {
			  doPortalJump = true;
			  numOfJumps += 1;
		  }
		  if (numOfJumps < 2)
		  {
			  int tempRow = getNextRow(row, col, dir, doPortalJump);
			  int tempCol = getNextColumn(row, col, dir, doPortalJump);
			  row = tempRow;
			  col = tempCol;
		  }
		  else if (numOfJumps == 2)
		  {
			  doPortalJump = false;
			  int tempRow = getNextRow(row, col, dir, doPortalJump);
			  int tempCol = getNextColumn(row, col, dir, doPortalJump);
			  row = tempRow;
			  col = tempCol;
		  }
		  currentCell = getCell(row, col);
		  
		  if (isMovable(currentCell.getState()) == true)
		  {
			  movable = true;
		  }
	  }
		  cellSeq.add(currentCell);
	  
	  Cell[] result = new Cell[cellSeq.size()];
	  for (int i = 0; i < cellSeq.size(); i++)
	  {
		  result[i] = cellSeq.get(i);
	  }
	  return result;
  }
  
  /**
   * Sets the given cell sequence and updates the player position.
   * This method effectively retraces the steps for creating a cell sequence in the given direction,
   * starting with the player's current position, and updates the grid with the new cells.
   * Exactly one cell in the given sequence must have the condition isPlayerPresent true.
   * The given cell sequence can be assumed to be structurally consistent with the existing grid,
   * e.g., no portal or wall cells are moved.
   * @param cells
   * updated cells to replace existing ones in the sequence
   * @param dir
   * direction of the cell sequence
   */
  public void setCellSequence(Cell[] cells, Direction dir)
  {
	  {
		  boolean doPortalJump = false;
		  int row = currentRow;
		  int col = currentCol;
		  Cell tempCell = new Cell(grid[row][col]);
		  int numOfJumps = 0;
		  while (CellState.isBoundary(tempCell.getState(), false) == false || CellState.isBoundary(tempCell.getState(), true) == false)
		  {
			  for (int i = 0; i < cells.length - 1; i++)
			  {
				  int prevRow = grid[row][col].getRowOffset();
				  int prevCol = grid[row][col].getColumnOffset();
				  grid[row][col] = new Cell(cells[i].getState());
				  grid[row][col].setOffsets(prevRow, prevCol);
				  
			  if (cells[i].isPlayerPresent())
			  {
				  grid[row][col].setPlayerPresent(true);
				  currentRow = getCurrentRow();
				  currentCol = getCurrentColumn();
			  }
			  
			  if (tempCell.getState() == CellState.PORTAL)
			  {
				  doPortalJump = true;
				  numOfJumps += 1;
			  }
			  if (numOfJumps < 2)
			  {
				  int tempRow = getNextRow(row, col, dir, doPortalJump);
				  int tempCol = getNextColumn(row, col, dir, doPortalJump);
				  row = tempRow;
				  col = tempCol;
				  tempCell = new Cell(grid[row][col]);
			  }
			  else if (numOfJumps == 2)
			  {
				  doPortalJump = false;
				  int tempRow = getNextRow(row, col, dir, doPortalJump);
				  int tempCol = getNextColumn(row, col, dir, doPortalJump);
				  row = tempRow;
				  col = tempCol;
				  tempCell = new Cell(grid[row][col]);
			  }
		  }
		  }
			  grid[row][col] = new Cell(cells[cells.length - 1]);
			  if (grid[row][col].isPlayerPresent() == true)
			  {
					currentRow = getCurrentRow();
					currentCol = getCurrentColumn();
			  }
	  }
  }
  
  /**
   * Helper method returns the next row for a cell sequence in the given direction, possibly wrapping around.
   * If the flag doPortalJump is true, then the next row will be obtained by adding the cell's row offset.
   * (Normally the caller will set this flag to true when first landing on a portal,
   * but to false for the second portal of the pair.)
   * @param row
   * row for current cell
   * @param col
   * column for current cell
   * @param dir
   * direction
   * @param doPortalJump
   * true if the next cell should be based on a portal offset in case the current cell is a portal
   * @return
   * next row number in a cell sequence
   */
  public int getNextRow(int row, int col, Direction dir, boolean doPortalJump)
  {
	  int nextRow = 0;
	  if (doPortalJump == false)
	  {
		  if (dir == Direction.RIGHT || dir == Direction.LEFT)
		  {
			  nextRow = row;
		  }
		  else if (dir == Direction.DOWN)
		  {
			  nextRow = (row + 1)%getRows();
		  }
		  else if (dir == Direction.UP)
		  {
			  nextRow = (row - 1 + getRows())%getRows();
		  }
	  }
	  else
	  {
		  nextRow = row + getCell(row, col).getRowOffset();
	  }
	  return nextRow;
  }
  
  /**
   * Helper method returns the next column for a cell sequence in the given direction, possibly wrapping around.
   * If the flag doPortalJump is true, then the next column will be obtained by adding the cell's column offset.
   * (Normally the caller will set this flag to true when first landing on a portal,
   * but to false for the second portal of the pair.)
   * @param row
   * row for current cell
   * @param col
   * column for current cell
   * @param dir
   * direction
   * @param doPortalJump
   * true if the next cell should be based on a portal offset in case the current cell is a portal
   * @return
   * next column number in a cell sequence
   */
  public int getNextColumn(int row, int col, Direction dir, boolean doPortalJump)
  {
	  int nextCol = 0;
	  if (doPortalJump == false)
	  {
		  if (dir == Direction.UP || dir == Direction.DOWN)
		  {
			  nextCol = col;
		  }
		  else if (dir == Direction.RIGHT)
		  {
			  nextCol = (col + 1)%getColumns();
		  }
		  else if (dir == Direction.LEFT)
		  {
			  nextCol = (col - 1 + getColumns())%getColumns();
		  }
	  }
	  else
	  {
		  nextCol = col + getCell(row, col).getColumnOffset();
	  }
	  return nextCol;
  }
  
  /**
   * Returns the number of pearls left in the grid.
   * @return
   * number of pearls in the grid
   */
  public int countPearls()
  {
	  return totalPearls - scores;
  }
}
