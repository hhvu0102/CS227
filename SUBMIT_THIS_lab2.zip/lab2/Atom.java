package lab2;
/**
 * Model of an Atom.
 */

public class Atom {
	   /**
	   * The number of protons in this atom
	   */
	  private int Protons;
	  
	  /**
	   * The number of neutrons in this atom
	   */
	  private int Neutrons;
	  
	  /**
	   * The number of electrons in this atom
	   */
	  private int Electrons;
	  
	  /**
	   * Constructs an Atom with the given number of particles
	   * @param givenProtons
	   * the number of protons in this Atom
	   * @param givenNeutrons
	   * the number of neutrons in this Atom
	   * @param givenElectrons 
	   * the number of electrons in this Atom
	   */
	  public Atom(int givenProtons, int givenNeutrons, int givenElectrons)
	  {
        // insert code to assign given values to instance variables 
		Protons = givenProtons;
		Neutrons = givenNeutrons;
		Electrons = givenElectrons;
	  }
	
	  /**
	  * Returns the mass of this Atom, which is total number of protons plus neutrons
	  * @return
	  * total number of protons plus neutrons
	  */
	  public int getAtomicMass()
	  {
		  // protons plus neutrons
		  int result = Protons + Neutrons;
		  return result;
	  }
	  
	  /**
	  * Returns the difference between the number of protons and electrons
	  * @return
	  * the difference between the number of protons and electrons
	  */
	  public int getAtomicCharge()
	  {
		  // protons minus electrons
		  int result = Protons - Electrons;
		  return result;
	  }
	  
	  /**
	   * Decays this Atom
	   * Decreases the number of protons by 2 and the number of neutrons by 2
	   */
	  public void decay()
	  {
	      // protons - 2 and neutrons - 2
		  Protons = Protons - 2;
		  Neutrons = Neutrons -2;
	  }
	
	}

