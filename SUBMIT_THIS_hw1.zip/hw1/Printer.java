package hw1;
/**
 * Model of the usage of paper and ink in a printer.
 * @author HaVu
 */
public class Printer
{
	  /**
	   * Capacity of this printer, in sheets.
	   */
	  private int capacity;
	  
	  /**
	   * Current number of papers in the printer.
	   */
	  private int numberOfSheets;
	  
	  /**
	   * The total number of papers that the printer has used.
	   */
	  private int totalPaperUsed;
	     
	  /**                     
	    * The amount of ink currently in the printer.
	    */
	  private double totalInk;

	   /**
		* Capacity, in ounces, of a new ink cartridge.
		*/
	   public static final double INK_CAPACITY = 2.0;

	   /**
   	    * Amount of ink, in ounces, used per printed page.
		*/
	   public static final double INK_USAGE = 0.0023;
	   	  
	  /**
	   * Constructs a printer with the given numbers of paper sheets it can hold and actually holds.
	   * @param givenCapacity
	   * the capacity of this printer.
	   */
	  public Printer(int givenCapacity)
	  {
		capacity = givenCapacity;
		numberOfSheets = 0;
		totalInk = INK_CAPACITY;
	  }
	   
	  /**
	   * Constructs a printer with the given numbers of paper sheets it can hold and actually holds.
	   * @param givenCapacity
	   * the capacity of this printer.
	   * @param givenNumberofSheets
	   * the current number of paper sheets in this printer.
	   */
	  public Printer(int givenCapacity, int givenNumberOfSheets)
	  { 
		capacity = givenCapacity;
		numberOfSheets = Math.min(givenCapacity, givenNumberOfSheets);
		totalInk = INK_CAPACITY;
	  }
	    
	  /**
	   * Returns the current total number of paper sheets.
	   * @return
	   * the current total number of paper sheets.
	   */
	  	public int getCurrentPaper()
		  {
			  int currentPaper = numberOfSheets;
			  return currentPaper;
		  }
	  	
	   /**
	    * Increases in number of sheets if we add more, not exceeding the capacity.
	    * @param additionalSheets
	    * the number of sheets that are added.
	    */
	    public void addPaper(int additionalSheets)
	      {
		      int spacePaper = capacity - numberOfSheets;
		      int actualPaper = Math.min(spacePaper, additionalSheets);
		      numberOfSheets = numberOfSheets + actualPaper;
	      }
	  
	  /**
	   * Changes in number of sheets if we print one-sided, not below 0.
	   * @param numberOfPages
	   * the number of pages that are used to print.
	   */
	  public void print(int numberOfPages)
	  {
		  int sheetsUsed = Math.min(numberOfSheets, numberOfPages);
		  numberOfSheets = numberOfSheets - sheetsUsed;   
		  totalPaperUsed = totalPaperUsed + sheetsUsed;
		  totalInk = totalInk - sheetsUsed*INK_USAGE;
	  }

	  /**
	   * Returns the total number of sheets used for printing.
	   * @return
	   * the total number of sheets used for printing.
	   */
	   public int getTotalPaperUse()
	   {
		  return totalPaperUsed;
	   }
	  
	   /**
	    * Changes in number of sheets if we print two-sided.
	    * @param numberOfPages
	    * the number of pages that are used to print.
	    */
	   public void printTwoSided(int numberOfPages)
	   {
		   int sheetsEquiv = (int) Math.ceil(numberOfPages / 2.0);
		   int sheetsUsed2 = Math.min(numberOfSheets, sheetsEquiv);
		   int pagesUsed = Math.min(sheetsUsed2 * 2, numberOfPages);
		   numberOfSheets = numberOfSheets - sheetsUsed2;
		   totalPaperUsed = totalPaperUsed + sheetsUsed2;
		   totalInk = totalInk - pagesUsed*INK_USAGE;
		}
	   
	   /**
	    *  Determines whether the ink has run out.
        *  @return
        *  true if empty, false otherwise
	    */
	    public boolean isInkOut()
	    {
		  return totalInk < INK_USAGE;
	    }
	  
	   /**
	    * Replace the ink cartridge, full like original.
	    */
	    public void replaceInk()
	    {
		   totalInk = INK_CAPACITY;
	    }
}
