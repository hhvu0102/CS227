package mini1;
import java.util.Scanner;
import java.util.Arrays;

public class KeepMeInTheLoop {

	/**
	 * Private constructor disables instantiation.
	 */
	 private KeepMeInTheLoop() { }	
		
	/**
	 * @param s 
	 * given string 
	 * @param ch
	 * given character to find
	 * @param n
	 * occurrence to find
	 * @return
	 * index of nth occurrence,
	 * or -1 if the character does not occur n or more times
	 */
	public static int findNth(java.lang.String s, char ch, int n)
	{
		String character = Character.toString(ch);
		int index = s.indexOf(character);
		while (--n > 0 && index != -1)
			{
				index = s.indexOf(character, index + character.length());
			}
		return index;
	}
	
	/**
	 * Returns a new string in which all consonants in the given string are doubled.
	 * @param s
	 * given string
	 * @return
	 * new string with all consonants doubled
	 */
	public static java.lang.String doubleConsonants(java.lang.String s)
	{
		String result = "";
		String vowels = "aeiouAEIOU";
		char prev_char = '\0';
		for (int i = 0; i < s.length(); i++)
		{
		    if (vowels.indexOf(s.charAt(i)) >= 0)
		    {
		          result += s.charAt(i);
		    }
		    else if (i <= s.length() - 1 && s.charAt(i) != prev_char)
		    {
		          result += "" + s.charAt(i) + s.charAt(i);
		    }
		    prev_char = s.charAt(i);
		}
		return result;
	}
	
	/**
	 * Returns the number of iterations required until n is equal to 1, where each iteration updates n
	 * @param n
	 * given starting number
	 * @return
	 * number of iterations required to reach n == 1, or -1 if n is not positive
	 */
	public static int findStoppingTime(int n)
	{
		int count = 0;
		if (n == 0)
		{
			count = -1;
		}
		
		while (n > 1)
		{
			if (n%2 == 0)
			{
				n = n/2;
			}
			else
			{
				n = 3*n + 1;
			}
			count += 1;
		}
	
		return count;
	}
	
	/**
	 * Returns number of months before the balance is less than the monthly cost
	 * @param balance
	 * starting balance
	 * @param monthlyCost
	 * expenses per month at the start of your trip
	 * @param interestRate
	 * annual interest rate you earn on your savings
	 * @param increase
	 * amount per month that the monthly expenses increase
	 * @return
	 * number of months before the balance is less than the monthly cost
	 */
	public static int howLong(double balance, double monthlyCost, double interestRate, double increase)
	{
		int month = 0;
		while (monthlyCost <= balance)
		{
			balance = (balance - monthlyCost) * (1 + interestRate/12);
			monthlyCost = monthlyCost + increase;
			month++;
		}
		return month;
	}
	
	/**
	 * Determines whether the given string follows the rule, "i before e, except after c".
	 * @param s
	 * given string
	 * @return
	 * false if the given string violates the rule, true otherwise
	 */
	public static boolean isIBeforeE(java.lang.String s) 
	{
		s = s.toLowerCase();
		boolean iBeforeE = false;
		
		if (s.startsWith("ei"))
		{
			iBeforeE = false;
		}
		else if (s.contains("ei"))
		{
			int indexEI = s.indexOf("ei");
			while (indexEI >= 0)
			{
				if (String.valueOf(s.charAt(indexEI - 1)).equals("c"))
				{
					iBeforeE = true;
				}
				else
				{
					iBeforeE = false;
					break;
				}
				indexEI = s.indexOf("ei", indexEI + 1);
			}
		}
		else
		{
			if (s.contains("ie"))
			{
				int indexIE = s.indexOf("ie");
				while (indexIE >= 0)
				{
					if (String.valueOf(s.charAt(indexIE) - 1).equals("c"))
					{
						iBeforeE = false;
					}
					else
					{
						iBeforeE = true;
					}
					indexIE = s.indexOf("ie", indexIE + 1);
				}
			}
			else
			{
				iBeforeE = true;
			}
		}
		return iBeforeE;
	}

	/**
	 * Returns the second largest number in a string of integers. 
	 * @param nums
	 * string of text containing integers separated by whitespace
	 * @return
	 * second largest number in the given string
	 */
	public static int findSecondLargest(java.lang.String nums)
	{
		Scanner scanner = new Scanner(nums);
		int largest = scanner.nextInt();
		int secondLargest = largest;
		while (scanner.hasNextInt())
		{
			int number = scanner.nextInt();
			if (number >= largest)
			{
				secondLargest = largest;
				largest = number;
			}
			if (number >= secondLargest && number < largest)
			{
				secondLargest = number;
			}
		}
		return secondLargest;
	}
	/**
	 * Determines whether the two given strings are permutations (rearrangements) of each other.
	 * @param s
	 * given string
	 * @param t
	 * given string
	 * @return
	 * true if the given strings are permutations of each other, false otherwise
	 */
	private static final char[] sortedChars(String input)
	{
	     char [] chars =  input.toCharArray();
	     Arrays.sort(chars);
	     return chars;
	}

	public static boolean isPermutation(java.lang.String s, java.lang.String t)
	{
	    char[] sSorted = sortedChars(s);
	    char[] tSorted = sortedChars(t);

	    return Arrays.equals(sSorted, tSorted);
	}
	 
	/**
	 * Determines whether the string target occurs as a substring of string source where "gaps" are allowed between characters of target.
	 * @param source
	 * the given string in which to find the target characters
	 * @param target
	 * the characters to be found
	 * @return
	 * true if the characters in target can be found as a subsequence in source, false otherwise
	 */
	public static boolean containsWithGaps(java.lang.String source, java.lang.String target)
	{
		boolean containsWithGaps = false;
		String newTarget = "";
		int start = 0;
		for (int i = 0; i < target.length(); i++)
		{
			int index = source.indexOf(target.charAt(i), start);
			if (index >= 0)
			{
				newTarget = newTarget + source.charAt(index);
			}
			start = index + 1;
		}
		if (target.equals(newTarget))
		{
			containsWithGaps =  true;
		}
		return containsWithGaps;
	}
}

