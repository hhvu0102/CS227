package hw4;

/**
 * Scoring category that is satisfied by any hand.
 * The score is the sum of all die values.
 * 
 * @author HaVu
 */
public class Chance extends SumAllValues
{
	/**
	 * Constructs an Chance category with the given display name.
	 * @param name
	 * given name of the category
	 */
	public Chance(java.lang.String name)
	{
		super(name);
	}
	
	@Override
	public boolean isSatisfiedBy(Hand hand)
	{
		boolean satisfy = false;
		if (hand != null)
		{
			satisfy = true;
		}
		return satisfy;
	}
}
