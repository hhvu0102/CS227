package hw4;

/**
 * Scoring category for all primes. A hand satisfies this category only if all die values are prime numbers.
 * For a hand that satisfies this category, the score the sum of all die values; otherwise the score is zero.
 * The display name for this category is always the exact string "All Primes".
 * 
 * @author HaVu
 */
public class AllPrimes extends SumAllValues
{
	/**
	 * Constructs an AllPrimes with name "AllPrimes".
	 */
	public AllPrimes()
	{
		super("All Primes");
	}
	
	@Override
	public boolean isSatisfiedBy(Hand hand)
	{
		boolean satisfied = true;
		for (int i = 0; i < hand.getAllValues().length; i++)
		{
			if (isPrime(hand.getAllValues()[i]) == false)
			{
				satisfied = false;
				break;
			}
		}
		return satisfied;
	}
	  
	/**
	 * Checks if a number is prime
	 * @param m
	 * the integer to be checked
	 * @return
	 * true if the number is prime, false otherwise
	 */
	private boolean isPrime(int m)
	{
		boolean prime = true;
		if (m == 2)
		{
			prime = true;
		}
		else
		{
			for (int i = 2; i <= Math.sqrt(m); i++)
			{
				if (m % i == 0)
				{
					prime = false;
					break;
				}
				else
				{
					prime = true;
				}
			}
		}
		return prime;
	}
}

