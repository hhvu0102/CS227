package hw4;

import java.util.Comparator;

import hw4.api.Die;

/**
 * Comparator for ordering Die objects.  Dice are ordered first
 * by value; dice with the same value are ordered by their max value, and dice
 * with the same value and the same max value are ordered by whether they are
 * available, with available dice preceding non-available dice.
 * 
 * @author HaVu
 */
public class DieComparator implements Comparator<Die>
{
	/**
	 * Compare the dice based on given rules.
	 */
  @Override
  public int compare(Die left, Die right)
  {
    int result = 0;
    if (Math.abs(left.value() - right.value()) != 0)
    {
    	result = left.value() - right.value();
    }
    else
    {
    	if (Math.abs(left.maxValue() - right.maxValue()) != 0)
    	{
    		result = left.maxValue() - right.maxValue();
    	}
    	else
    	{
    		if (left.isAvailable() == true && right.isAvailable() == false)
    		{
    			result = -1;
    		}
    		else if (left.isAvailable() == false && right.isAvailable() == true)
    		{
    			result = 1;
    		}
    		else if ((left.isAvailable() == false && right.isAvailable() == false) || (left.isAvailable() == true && right.isAvailable() == true))
    		{
    			result = 0;
    		}
    	}
    }
    return result;
  }

}
