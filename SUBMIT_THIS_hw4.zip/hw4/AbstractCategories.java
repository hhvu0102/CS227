package hw4;

import hw4.api.ScoringCategory;

/**
 * Abstract class which contains all methods common of 9 categories.
 * @author HaVu
 *
 */
public abstract class AbstractCategories implements ScoringCategory
{
	/**
	 * name of the category.
	 */
	private String category;

	
	/**
	 * the hand used to fill the category.
	 */
	private Hand handToFill;
	
	/**
	 * Construct the parent abstract class for all 9 categories.
	 * @param givenName
	 * name of the category
	 */
	public AbstractCategories(String givenName)
	{
		category = givenName;
		handToFill = null;
	}
	
	public boolean isFilled()
	{
		return (handToFill != null);
	}
	  
	public int getScore()
	{
		if (isFilled() == true)
		{
			return getPotentialScore(handToFill);
		}
		else
		{
			return 0;
		}
	}

	public Hand getHand()
	{
		return handToFill;
	}
	  
	public String getDisplayName()
	{
		return category;
	}
	  
	public void fill(Hand hand)
	{
		if (isFilled() || !hand.isComplete())
		{
			throw new IllegalStateException();
		}
		else
		{
			handToFill = hand;
		}
	}
	
	public abstract boolean isSatisfiedBy(Hand hand);
	public abstract int getPotentialScore(Hand hand);
}
