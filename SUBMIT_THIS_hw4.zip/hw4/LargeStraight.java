package hw4;

import java.util.Arrays;

/**
 * Scoring category for a "large straight".
 * A hand with N dice satisfies this category only if there are N distinct consecutive values.
 * For a hand that satisfies this category, the score is a fixed value specified in the constructor; otherwise, the score is zero.
 * 
 * @author HaVu
 */
public class LargeStraight extends GivenScore
{	
	/**
	 * Constructs a LargeStraight category with the given display name and score.
	 * @param name
	 * given name of the category
	 * @param points
	 * the fixed point given if satisfied
	 */
	public LargeStraight(java.lang.String name, int points)
	{
		super(name, points);
	}
	
	@Override
	  public boolean isSatisfiedBy(Hand hand)
	  {
		  boolean satisfied = true;
		  Arrays.sort(hand.getAllValues());
		  for (int i = 0; i < hand.getAllValues().length - 1; i++)
		  {
			 if (hand.getAllValues()[i] != hand.getAllValues()[i+1] - 1)
			 {
				 satisfied = false;
				 break;
			 }
		  }
		  return satisfied;
	  }
}
