package hw4;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.Random;
import java.util.Comparator;

import hw4.api.Die;
import hw4.DieComparator;

/**
 * This class represents values of a group of dice for a dice game such as Yahtzee in which 
 * multiple rolls per turn are allowed. The number of faces on the dice, 
 * the number of dice in the Hand, and the maximum number of rolls are configurable 
 * via the constructor. At any time some of the dice may be <em>available</em>
 * to be rolled, and the other dice are <em>fixed</em>.  Calls to the 
 * <code>roll()</code> method roll the available
 * dice only.  After the maximum number of rolls, all dice are automatically
 * fixed; before that, the client can select which dice to "keep" (change from
 * available to fixed) and which dice to "free" (change from fixed to
 * available).
 * <p>
 * Note that valid die values range from 1 through the given
 * <code>maxValue</code>. 
 * 
 * @author HaVu
 */
public class Hand extends DieComparator
{
 /**
  * The number of dice in the game.
  */
  private int numOfDice;
	  
 /**
  * The maximum value of the dice.
  */
  private int numOfSides;
	  
  /**
   * The number of times the dice may be re-rolled in each round.
   */
  private int numOfRolls;

  /**
   * Current values of the dice in the hand.
   */
  private int[] currentValues;
  
  /**
   * Number of current available dice to be rolled.
   */
  private int numOfAvailDice;
  
  /**
   * Current dice in the hand.
   */
  private Die[] currentDice;
  
  /**
   * Constructs a new Hand in which each die initially has 
   * the value 1.
   * @param numDice
   *   number of dice in this group
   * @param maxValue
   *   largest possible die value, where values range from 1
   *   through <code>maxValue</code>
   * @param maxRolls
   *   maximum number of total rolls
   */
  public Hand(int numDice, int maxValue, int maxRolls)
  {
    numOfDice = numDice;
    numOfSides = maxValue;
    numOfRolls = maxRolls;
    numOfAvailDice = numDice;
    
    currentValues = new int[numDice];
    for (int i = 0; i < numDice; i++)
    {
    	currentValues[i] = 1;
    }
    
    currentDice = new Die[numOfDice];
    for (int j = 0; j < numOfDice; j++)
    {
    	currentDice[j] = new Die(currentValues[j], numOfSides);
    }
  }   
  
  /**
   * Constructs a new Hand in which each die initially has 
   * the value given by the <code>initialValues</code> array.
   * If the length of the array is greater than the number of dice, the
   * extra values are ignored.  If the length of the array is smaller
   * than the number of dice, remaining dice
   * will be initialized to the value 1.
   * <p>
   * This version of the constructor is primarily intended for testing.
   * @param numDice
   *   number of dice in this hand
   * @param maxValue
   *   largest possible die value, where values range from 1
   *   through <code>maxValue</code>
   * @param maxRolls
   *   maximum number of total rolls
   * @param initialValues
   *   initial values for the dice
   */
  public Hand(int numDice, int maxValue, int maxRolls, int[] initialValues)
  {
	 numOfDice = numDice;
	 numOfSides = maxValue;
	 numOfRolls = maxRolls;
	 numOfAvailDice = numDice;
	 
	 int n = initialValues.length;
	 currentValues = new int[numDice];
	 if (numDice <= n)
	 {
		 for (int i = 0; i < numDice; i++)
		 {
			 currentValues[i] = initialValues[i];
		 }
	 }
	 else
	 {
		 for (int i = 0; i < n; i++)
		 {
			 currentValues[i] = initialValues[i];
		 }
		 for (int j = n; j < numDice; j++)
		 {
			 currentValues[j] = 1;
		 }
	 }
	 
	 currentDice = new Die[numOfDice];
	 for (int k = 0; k < numOfDice; k++)
	 {
	 	currentDice[k] = new Die(currentValues[k], numOfSides);
	 }
  }  
  
  /**
   * Returns the number of dice in this hand.
   * @return
   *   number of dice in this hand
   */
  public int getNumDice()
  {
    return numOfDice;
  }
  
  /**
   * Returns the maximum die value in this hand.
   * Valid values start at 1.
   * @return
   *   maximum die value
   */
  public int getMaxValue()
  {
    return numOfSides;
  }
  
  /**
   * Rolls all available dice using the given random number generator.
   * If the number of rolls has reached the maximum, all dice are
   * marked as fixed.
   * @param rand
   *   random number generator to be used for rolling dice
   */
  public void roll(Random rand)
  {
    if (numOfRolls > 0)
    {
    	for (int i = 0; i < currentDice.length; i++)
    	{
    		if (currentDice[i].isAvailable() == true)
    		{
    			currentDice[i].roll(rand);
    		}
    	}
    }
	numOfRolls -= 1;
	if (numOfRolls == 0)
	{
		for (int j = 0; j < currentDice.length; j++)
		{
			currentDice[j].setAvailable(false);
		}
	}
	
	for (int k = 0; k < currentValues.length; k++)
	{
		currentValues[k] = currentDice[k].value();
	}
	
  }

  /**
   * Selects a single die value to be changed from the available dice to the
   * fixed dice. If there are multiple available dice with the given value, 
   * only one is changed to be fixed. Has no effect if the given value is 
   * not among the values in the available dice.  Has no effect if
   * the number of rolls has reached the maximum.
   * @param value
   *   die value to be changed from available to fixed
   */
  public void keep(int value)
  {
	for (int i = 0; i < currentDice.length; i++)
	{
		if (currentDice[i].value() == value && currentDice[i].isAvailable() == true && numOfRolls != 0)
		{
			currentDice[i].setAvailable(false);
			numOfAvailDice -= 1;
			break;
		}
	}
  }

  /**
   * Selects a die value to be moved from the fixed dice to
   * the available dice (i.e. so it will be re-rolled in the
   * next call to <code>roll()</code>). If there are multiple fixed dice 
   * with the given value, only one is changed be available. 
   * Has no effect if the given value is 
   * not among the values in the fixed dice. Has no effect if
   * the number of rolls has reached the maximum.
   * @param value
   *   die value to be moved
   */
  public void free(int value)
  {
	for (int i = 0; i < currentValues.length; i++)
	{
		if (currentDice[i].value() == value && currentDice[i].isAvailable() == false && numOfRolls != 0)
		{
			currentDice[i].setAvailable(true);
			numOfAvailDice += 1;
			break;
		}
	}
  }
  
  /**
   * Causes all die values to be changed from available to fixed.
   * Has no effect if the number of rolls has reached the maximum.
   */
  public void keepAll()
  {
	for (int i = 0; i < currentDice.length; i++)
	{
	  if (currentDice[i].isAvailable() == true && numOfRolls != 0)
	  {
		  currentDice[i].setAvailable(false);
	  }
	}
	numOfAvailDice = 0;
  }
  
  
  /**
   * Causes all die values to be changed from fixed to available. 
   * Has no effect if the number of rolls has reached the maximum.
   */
  public void freeAll()
  {
	for (int i = 0; i < currentDice.length; i++)
	{
		if (currentDice[i].isAvailable() == false && numOfRolls != 0)
		{
			currentDice[i].setAvailable(true);
		}
	}
	numOfAvailDice = numOfDice;
  }
  
  /**
   * Determines whether there are any dice available to be 
   * rolled in this hand.
   * @return
   *   true if there are no available dice, false otherwise
   */
  public boolean isComplete()
  {
    return (numOfAvailDice == 0 || numOfRolls == 0);
  }

  /**
   * Gives out the dices that have been fixed
   * @return
   * an array of fixed dice
   */
  public Die[] getFixedDice()
  {
	ArrayList<Die> fixedList = new ArrayList<Die>();
	for (int i = 0; i < currentDice.length; i++)
	{
		if (currentDice[i].isAvailable() == false)
		{
			fixedList.add(currentDice[i]);
		}
	}
	Die[] result = new Die[fixedList.size()];
	for (int j = 0; j < fixedList.size(); j++)
	{
		result[j] = fixedList.get(j);
	}
	
	orderedDice(result);
	return result;
  }

  /**
   * Gives out the dices that are available
   * @return
   * an array of available dice
   */
  public Die[] getAvailableDice()
  {
    ArrayList<Die> availList = new ArrayList<Die>();
	for (int i = 0; i < currentDice.length; i++)
	{
		if (currentDice[i].isAvailable() == true)
		{
			availList.add(currentDice[i]);
		}
	}
	Die[] result = new Die[availList.size()];
	for (int j = 0; j < availList.size(); j++)
	{
		result[j] = availList.get(j);
	}
	
	orderedDice(result);
    return result;
  }
  
 
  /**
   * Returns all die values in this hand, in ascending order.
   * @return
   *   all die values in this hand
   */
  public int[] getAllValues()
  {
    Arrays.sort(currentValues);
    return currentValues;
  }
  
  /**
   * Returns an array of all the dice in this hand.
   * @return
   *  array of all dice 
   */
  public Die[] getAllDice()
  {
	orderedDice(currentDice);
    return currentDice;
  }
  
  /**
   * Order the dice according to the logic in DieComparator
   * @param arr
   *  an array of dice to order
   */
  private void orderedDice(Die[] arr)
  {
	  Comparator<Die> compa = new DieComparator();
	  Arrays.sort(arr, compa);
  }
}
