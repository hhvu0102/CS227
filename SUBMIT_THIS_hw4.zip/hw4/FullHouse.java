package hw4;

import java.util.Arrays;

/**
 * Scoring category for a generalized full house.
 * A hand with N dice satisfies this category only in the following cases:
 * If N is even, there are two different values, each occurring exactly N/2 times. 
 * If N is odd, there are two different values, one of them occurring N/2 times and the other occurring N/2 + 1 times.
 * For a hand that satisfies this category, the score is a fixed value specified in the constructor;
 * otherwise, the score is zero.
 * 
 * @author HaVu
 */
public class FullHouse extends GivenScore
{	
	/**
	 * Constructs an FullHouse with the given display name and score.
	 * @param name
	 * given name of the category
	 * @param points
	 * the fixed point given if satisfied
	 */
	public FullHouse(java.lang.String name, int points)
	{
		super(name, points);
	}
	
	@Override
	  public boolean isSatisfiedBy(Hand hand)
	  {
		  boolean satisfied = false;
		  boolean firstHalf = false;
		  boolean secondHalf = false;
		  int[] allValues = hand.getAllValues();
		  int n = allValues.length;
		  int middle = n/2;
		  
		// I first sort the value array.
		  Arrays.sort(allValues);
		  
		// If the array length is even, then iterate through the first and second half of the array.
		  if (n%2 == 0)
		  {
			  for (int i = 0; i < middle - 1; i++)
			  {
				  if (allValues[i] == allValues[i+1])
				  {
					  firstHalf = true;
				  }
				  else
				  {
					  firstHalf = false;
					  break;
				  }
			  }
			  for (int j = middle; j < n - 1; j++)
			  {
				  if (allValues[j] == allValues[j+1])
				  {
					  secondHalf = true;
				  }
				  else
				  {
					  secondHalf = false;
					  break;
				  }
			  }
			  
			// If all values in the first half are the same, and so are those in the second half, I check
			// the values at middle - 1 and middle. If they are not equal, then satisfied.
			  if (firstHalf == true && secondHalf == true)
			  {
				  satisfied = (allValues[middle-1] - allValues[middle]) != 0;
			  }
		  }
		  
		// Same reasoning applied for the case the array length is odd.
		  else
		  {
			 // If the smaller value has n/2 numbers and the larger one has n/2+1
			 // Check the first half of the values
			  for (int i = 0; i < middle - 1; i++)
			  {
				  if (allValues[i] == allValues[i+1])
				  {
					  firstHalf = true;
				  }
				  else
				  {
					  firstHalf = false;
					  break;
				  }
			  }
			  for (int j = middle; j < n - 1; j++)
			  {
				  if (allValues[j] == allValues[j+1])
				  {
					  secondHalf = true;
				  }
				  else
				  {
					  secondHalf = false;
					  break;
				  }
			  }
				  
			// If the smaller value has n/2+1 numbers and the larger one has n/2
			if (secondHalf == false)
			{
				for (int k = 0; k < middle; k++)
				{
					if (allValues[k] == allValues[k + 1]) 
					{
						firstHalf = true;
					} 
					else 
					{
						firstHalf = false;
						break;
					}
				}

				for (int h = middle + 1; h < n - 1; h++) 
				{
					if (allValues[h] == allValues[h + 1]) 
					{
						secondHalf = true;
					} 
					else 
					{
						secondHalf = false;
						break;
					}
				}
			}
			  
			// If all values in the first half are the same, and so are those in the second
			// half, I check the values at middle -/+ 1 and middle. If they are not equal, then satisfied.
			if (firstHalf == true && secondHalf == true)
			{
				satisfied = (allValues[middle - 1] != allValues[middle] || allValues[middle + 1] != allValues[middle]);
			}
		  }
		  
		  return satisfied;
	  }
}
