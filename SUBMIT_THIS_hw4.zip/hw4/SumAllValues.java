package hw4;

/**
 * Abstract class for categories which if one satisfies, the score is the sum of all die values.
 * @author HaVu
 *
 */
public abstract class SumAllValues extends AbstractCategories
{
	/**
	 * Constructor for abstract class for categories which if one satisfies, the score is the sum of all die values.
	 * @param givenName
	 * the given name for the category
	 */
	public SumAllValues(String givenName)
	{
		super(givenName);
	}
	
	@Override
	public int getPotentialScore(Hand hand)
	  {
		  int score = 0;
		  if (isSatisfiedBy(hand) == false)
		  {
			  score = 0;
		  }
		  else
		  {
			  for (int i = 0; i < hand.getAllValues().length; i++)
			  {
				  score = score + hand.getAllValues()[i];
			  }
		  }
		  return score;
	  }
	
	public abstract boolean isSatisfiedBy(Hand hand);
}
