package hw4;

/**
 * Abstract class for categories which if one satisfies, he is given a fixed score.
 * @author HaVu
 *
 */
public abstract class GivenScore extends AbstractCategories
{
	/**
	 * the score received if satisfied.
	 */
	private int scoreExpected;
	
	/**
	 * Constructor for abstract class for categories which if one satisfies, he is given a fixed score.
	 * @param givenName
	 * the given name for the category
	 * @param points
	 * the given point for the category
	 */
	public GivenScore(String givenName, int points)
	{
		super(givenName);
		scoreExpected = points;
	}
	
	@Override
	public int getPotentialScore(Hand hand)
	{
		int score = 0;
		if (isSatisfiedBy(hand) == false)
		{
			score = 0;
		}
		else
		{
			score = scoreExpected;
		}
		return score;
	}
	
	public abstract boolean isSatisfiedBy(Hand hand);
}
