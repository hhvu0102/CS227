package hw4;

/**
 * Scoring category that is based on counting occurrences of a particular target value
 * (specified in the constructor). This category is satisfied by any hand.
 * The score is the sum of just the die values that match the target value.
 * 
 * @author HaVu
 */
public class CountOccurrences extends AbstractCategories
{
	/**
	 * the target value of the category.
	 */
	private int target;

	/**
	 * Constructs a CountOccurrences category with the given display name and target value.
	 * @param name
	 * name for this category
	 * @param number
	 * target value that must be matched for a die to count toward the score
	 */
	public CountOccurrences(java.lang.String name, int number)
	{
		super(name);
		target = number;
	}
	
	@Override
	public boolean isSatisfiedBy(Hand hand)
	{
		boolean satisfy = false;
		if (hand != null)
		{
			satisfy = true;
		}
		return satisfy;
	}
	  
	@Override
	public int getPotentialScore(Hand hand)
	{
		int score = 0;
		int numOfTarget = 0;
		if (isSatisfiedBy(hand) == false)
		{
			score = 0;
		}
		else
		{
			for (int i = 0; i < hand.getAllValues().length; i++)
			{
				if (hand.getAllValues()[i] == target)
				{
					numOfTarget += 1;
				}
			}
			score = numOfTarget * target;
		}
		return score;
	}
}
