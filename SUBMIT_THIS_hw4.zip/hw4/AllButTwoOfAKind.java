package hw4;

import java.util.Arrays;

/**
 * Scoring category for (N-2) of a kind.
 * A hand with N dice satisfies this category only if at least N - 2 of the values are the same.
 * For a hand that satisfies this category,
 * the score the sum of all die values; otherwise the score is zero.
 * 
 * @author HaVu
 */
public class AllButTwoOfAKind extends SumAllValues
{
	/**
	 * Constructs an AllButTwoOfAKind category with the given display name.
	 * @param name
	 * given name of the category
	 */
	public AllButTwoOfAKind(java.lang.String name)
	{
		super(name);
	}
	
	@Override
	public boolean isSatisfiedBy(Hand hand)
	{
		boolean satisfied = false;
		int numOfRepeat = 1;
		Arrays.sort(hand.getAllValues());
		if (hand.getNumDice() == 0 || hand.getNumDice() == 3)
		{
			satisfied = true;
		}
		else
		{
			for (int i = 0; i < hand.getAllValues().length - 1; i++)
			{
				if (hand.getAllValues()[i] == hand.getAllValues()[i + 1])
				{
					numOfRepeat += 1;
					if (numOfRepeat >= hand.getNumDice() - 2)
					{
						satisfied = true;
					}
				}
				else
				{
					numOfRepeat = 1;
				}
			}
		}
		
		return satisfied;
	}
}
