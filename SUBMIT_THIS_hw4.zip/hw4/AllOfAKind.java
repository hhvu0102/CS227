package hw4;

import java.util.Arrays;

/**
 * Scoring category for a "yahtzee". A hand with N dice satisfies this category only if all N values are the same.
 * For a hand that satisfies this category,
 * the score is a fixed value specified in the constructor; otherwise, the score is zero.
 * 
 * @author HaVu
 */
public class AllOfAKind extends GivenScore
{	
	/**
	 * Constructs an AllOfAKind with the given display name and score.
	 * @param name
	 * given name of the category
	 * @param points
	 * the fixed point given if satisfied
	 */
	public AllOfAKind(java.lang.String name, int points)
	{
		super(name, points);
	}
	
	@Override
	public boolean isSatisfiedBy(Hand hand)
	{
		boolean satisfied = false;
		int numOfRepeat = 1;
		Arrays.sort(hand.getAllValues());
		if (hand.getNumDice() == 0)
		{
			satisfied = true;
		}
		else
		{
			for (int i = 0; i < hand.getAllValues().length - 1; i++)
			{
				if (hand.getAllValues()[i] == hand.getAllValues()[i + 1])
				{
					numOfRepeat += 1;
				}
			}
			if (numOfRepeat == hand.getNumDice())
			{
				satisfied = true;
			}
		}

		return satisfied;
	}
}
