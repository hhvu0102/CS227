package mini2;
import java.util.Arrays;
import java.util.ArrayList;

public class HipHipArray {
	
	/**
	 * Private constructor disables instantiation.
	 */
	private HipHipArray() {}
	
	/**
	 * @param data - the data set
	 * @param numBins - number of bins for the histogram
	 * @param min - lower bound (inclusive) for numbers to be included in the histogram
	 * @param max - upper bound (exclusive) for numbers to be included in the histogram
	 * @return
	 * array whose ith cell contains the number of data values in bin i
	 */
	public static int[] makeHistogram(double[] data, int numBins, double min, double max)
	{
		int[] result = new int[numBins];
		int count = 0;
		double binSize = (max - min)/numBins;
		for (int i = 0; i < numBins; i++)
		{
			count = 0;
			for (int j = 0; j < data.length; j++)
			{
				if ((data[j] >= min + i*binSize) && (data[j] < min + (i+1)*binSize))
				{
					count +=1;
				}
				result[i] = count;
			}
		}
		return result;
	}
	
	/**
	 * @param arr - array to be checked
	 * @return
	 * true if the given array is a permutation, false otherwise
	 */
	public static boolean isPermutation(int[] arr)
	{
		int n = arr.length;
		boolean isPermutation = false;
		int[] copiedArr = new int[n];
		for (int j = 0; j < n; j++)
		{
		copiedArr[j] = arr[j];
		}
		Arrays.sort(copiedArr);
		for (int i = 0; i < n; i++)
		{
			if (copiedArr[i] == i)
			{
				isPermutation = true;
			}
			else
			{
				isPermutation = false;
				break;
			}
		}
		return isPermutation;
	}

	/**
	 * Given an array of length n, return a new array of length 2n - 1 that is a "palindrome"
	 * @param arr - given array
	 * @return
	 * new array with elements appended in reverse
	 */
	public static int[] createPalindrome(int[] arr)
	{
		int n = arr.length;
		if (n == 0)
		{
			return arr;
		}
		else {
		int[] palindrome = new int[2*n - 1];
		for (int i = 0; i < n; i++)
		{
			palindrome[i] = arr[i];
		}
		for (int j = n; j < (2*n - 1); j++)
		{
			palindrome[j] = arr[2*n - j - 2];
		}
		return palindrome;
		}
	}
	
	/**
	 * Creates a boolean array arr of the given size such that arr[i] is true if and only if the number i is not divisible by any number in the given array divisors that is strictly smaller than i.
	 * @param size
	 * size of the returned array
	 * @param divisors
	 * numbers to check for divisibility
	 * @return
	 * array whose ith cell contains false only if the number i is divisible by at least one element of the given array that is strictly smaller than i
	 */
	public static boolean[] makeSieve(int size, int[] divisors)
	{
		boolean[] result = new boolean[size];
		result[0] = false;
		result[1] = true;
		for (int i = 2; i < size; i++)
		{
			result[i] = true;
			for (int j = 0; j < divisors.length; j++)
			{
				if ((i % divisors[j] == 0) && (i > divisors[j]))
				{
					result[i] = false;
				}
			}
		}
		return result;
	}
	
	/**
	 * Shifts the elements of the given array by the given amount, shifting right if amount is positive and left if amount is negative. 
	 * @param arr
	 * given array to be modified
	 * @param amount
	 * amount of shift
	 */
	public static void shift(int[] arr, int amount)
	{
		int n = arr.length;
		int[] copiedArr = new int[n];
		
		for (int k = 0; k < n; k++)
		{
			copiedArr[k] = arr[k];
		}
		
		if (Math.abs(amount) > n)
		{
			for (int i = 0; i < n; i++)
			{
				copiedArr[i] = 0;
			}
		}
		else if (amount > 0 && amount <= n)
		{
			for (int j = 0; j < n - amount; j++)
			{
				copiedArr[j + amount] = arr[j];
			}
			
			for (int l = 0; l < amount; l++)
			{
				copiedArr[l] = 0;
			}
		}
		else if (amount < 0 && Math.abs(amount) <= n)
		{
			for (int h = n - 1; h >= Math.abs(amount); h = h - 1)
			{
				copiedArr[h + amount] = arr[h];
			}
			
			for (int u = n - 1; u >= n + amount; u = u - 1)
			{
				copiedArr[u] = 0;
			}
		}
		
		for (int m = 0; m < n; m++)
		{
			arr[m] = copiedArr[m];
		}
	}
	
	/**
	 * Rotates the elements of the given array by the given amount, towards the right if amount is positive and left if amount is negative.
	 * @param arr
	 * given array to be modified
	 * @param amount
	 * amount of rotation
	 */
	public static void rotate(int[] arr, int amount)
	{
		int rotateAmount = 0;
		int n = arr.length;
		int[] newArr = new int[n];
		if (amount > 0)
		{
			rotateAmount = amount % n;
		}
		else if (amount < 0)
		{
			rotateAmount = ((amount % n) + n) % n;
		}
		for (int i = 0; i < n; i++)
		{
			if (i < n - rotateAmount)
			{
				newArr[i + rotateAmount] = arr[i];
			}
			else
			{
				newArr[rotateAmount + i - n] = arr[i];
			}
		}
		for (int j = 0; j < n; j++)
		{
			arr[j] = newArr[j];
		}
	}
	
	/**
	 * Returns a new array with duplicate elements removed. The relative ordering of the first occurrence of each element is unchanged. The given array is not modified.
	 * @param arr
	 * given array
	 * @return
	 * new array with duplicates removed
	 */
	public static java.lang.String[] removeDups(java.lang.String[] arr)
	{
		ArrayList<String> diffElements = new ArrayList<String>();
		for (int i = 0; i < arr.length; i++)
		{
			if (! diffElements.contains(arr[i]))
			{
				diffElements.add(arr[i]);
			}
		}
		String[] result = diffElements.toArray(new String[diffElements.size()]);
		return result;
	}
	
	/**
	 * returns a new array consisting of the longest run of consecutive nondecreasing values in the given array.
	 * @param arr
	 * given array
	 * @return
	 * array containing longest nondecreasing run in the given array
	 */
	public static int[] longestRun(int[] arr)
	{
		ArrayList<Integer> tempList = new ArrayList<>();
		ArrayList<ArrayList<Integer>> arrays = new ArrayList<>();
		int prevNum = arr[0];
		tempList.add(prevNum);
		
		for (int i = 1; i < arr.length; i++)
		{
		    if (arr[i] >= prevNum)
		    {
		        tempList.add(arr[i]);
		        prevNum = arr[i]; 
		        if (i == arr.length - 1) // add the finishing array into the arrayList
		        {
		        	arrays.add(tempList);
		        }
		    }
		    else
		    { 
		        arrays.add(tempList);
		        tempList = new ArrayList<>();
		        prevNum = arr[i];
		        tempList.add(prevNum);
		    }
		}
		
		ArrayList<Integer> longestRun = new ArrayList<>();
		for (ArrayList<Integer> subArr : arrays)
		{
		    if (subArr.size() > longestRun.size())
		    {
		        longestRun = subArr;
		    }
		}
		
		
		int[] result = new int[longestRun.size()];
		for (int j = 0; j < result.length; j++)
		{
		    result[j] = longestRun.get(j);
		}
		return result;
	}
}
