package hw2;
//import hw2.TennisGame.*;

/**
 * Model of a tennis set.
 * @author HaVu
 */
public class Set {
	
	/**
	 * the player who serves first
	 */
	private int currentPlayer;
	
	/**
	 * the minimum number of games one must get to win the set.
	 */
	private int minGamesToWin;
	
	/**
	 * a tennis game.
	 */
	private TennisGame game;
	
	/**
	 * the number of games player 0 wins
	 */
	private int player0GamesNum;
	
	/**
	 * the number of games player 1 wins
	 */
	private int player1GamesNum;

	/**
	 * Constructs a set with the given minimum number of games.
	 * @param minimumGamesToWin
	 * number of games needed to win the set
	 * @param player1ServesFirst
	 * true if player 1 is the server in the first game
	 */
	public Set(int minimumGamesToWin, boolean player1ServesFirst)
	{
		minGamesToWin = minimumGamesToWin;
		
		if (player1ServesFirst == true)
		{
			currentPlayer = 1;
		}
		else
		{
			currentPlayer = 0;
		}
		
		game = new TennisGame();
	}

	/**
	 * Invokes serve on the current game and
	 * updates the winner's count of games won if the action ends the current game.
	 * @param serviceFault
	 */
	public void serve(boolean serviceFault)
	{ 
		if ((game.isOver() == false) && (isSetOver() == false))
		{
			game.serve(serviceFault);	
		
			if (game.isOver() == true)
			{
				if (currentPlayer == 1)
				{
					player1GamesNum = player1GamesNum + 1;
				}
				else
				{
					player0GamesNum = player0GamesNum + 1;
				}
			}
		}
	}
	
	/**
	 * Invokes hit on the current game and
	 * updates the winner's count of games won if the action ends the current game.
	 * @param fault
	 * true if the hit results in a fault ending the rally
	 * @param outOfBounds
	 * true if the hit goes over the net but on an out of bounds trajectory
	 */
	public void hit(boolean fault, boolean outOfBounds)
	{
		if ((game.isOver() == false) && (isSetOver() == false))
		{
			game.hit(fault, outOfBounds);
		
			if (game.isOver() == true)
			{
				if (currentPlayer == 1)
				{
					player1GamesNum = player1GamesNum + 1;
				}
				else
				{
					player0GamesNum = player0GamesNum + 1;
				}
			}	
		}
	}
	
	/**
	 * Invokes miss on the current game and
	 * updates the winner's count of games won if the action ends the current game.
	 */
	public void miss()
	{
		if ((game.isOver() == false) && (isSetOver() == false))
		{
			game.miss();
	
			if (game.isOver() == true)
			{
				if (currentPlayer == 1)
				{
					player1GamesNum = player1GamesNum + 1;
				}
				else
				{
					player0GamesNum = player0GamesNum + 1;
				}
			}
		}
	}
	
	/**
	 * Invokes setScore on the current game and
	 * updates the winner's count of games won if the action ends the current game.
	 * @param serverScore
	 * score to be set for the server
	 * @param receiverScore
	 * score to be set for the receiver
	 */
	public void fastForward(int serverScore, int receiverScore)
	{
		if ((game.isOver() == false) && (isSetOver() == false))
		{
			game.setScore(serverScore, receiverScore);
			
			if (game.isOver() == true)
			{
				if (((currentPlayer == 1) && (game.serverWon() == true)) || ((currentPlayer == 0) && (game.receiverWon() == true)))
				{
					player1GamesNum = player1GamesNum + 1;
				}
				else if (((currentPlayer == 0) && (game.serverWon() == true)) || ((currentPlayer == 1) && (game.receiverWon() == true)))
				{
					player0GamesNum = player0GamesNum + 1;
				}
			}
		}
	}
	
	/**
	 * Starts a new game in this set, switching the service to the opposite player.
	 */
	public void newGame()
	{
		if ((isCurrentGameOver() == true) && (isSetOver() == false))
		{
			game = new TennisGame();
			if (currentPlayer == 1)
			{
				currentPlayer = 0;			
			}
			else
			{
				currentPlayer = 1;
			}
		}
	}
	
	/**
	 * Returns true if the current game is over.
	 * @return
	 * true if the current game is over, false otherwise
	 */
	public boolean isCurrentGameOver()
	{
		return game.isOver();
	}
	
	/**
	 * Returns true if the set is over.
	 * @return
	 * true if the set is over, false otherwise
	 */
	public boolean isSetOver()
	{
		return ((player0GamesNum >= minGamesToWin) || (player1GamesNum >= minGamesToWin) && Math.abs(player1GamesNum - player0GamesNum) >= 2);
	}
	
	/**
	 * Returns a string representation of the current status of the set in the form "Set: x-y Game: ss".
	 * @param useCallString
	 * @return
	 */
	public java.lang.String getCurrentStatus(boolean useCallString)
	{
		if (useCallString == false)
		{
			if (currentPlayer == 0)
			{
				return "Set: " + player0GamesNum + "-" + player1GamesNum + " " + "Game: " + game.getScore();
			}
			else
			{
				return "Set: " + player1GamesNum + "-" + player0GamesNum + " " + "Game: " + game.getScore();
			}
		}
		else
		{
			if (currentPlayer == 0)
			{
				return "Set: " + player0GamesNum + "-" + player1GamesNum + " " + "Game: " + game.getCallString();
			}
			else
			{
				return "Set:" + player1GamesNum + player0GamesNum + " " + "Game:" + game.getCallString();
			}
		}
	}
	
	/**
	 * Returns the player (0 or 1) who is the server in the current game.
	 * @return
	 * server in the current game
	 */
	public int whoIsServing()
	{
		return currentPlayer;
	}
	
	/**
	 * Returns the number of games won by player 0.
	 * @return
	 * number of games won by player 0
	 */
	public int player0GamesWon()
	{
		return player0GamesNum;
	}
	
	/**
	 * Returns the number of games won by player 1.
	 * @return
	 * number of games won by player 1
	 */
	public int player1GamesWon()
	{
		return player1GamesNum;
	}
}
