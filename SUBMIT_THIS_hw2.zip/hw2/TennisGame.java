package hw2;
import static hw2.BallDirection.*;

/**
 * Model of a tennis game.
 * @author HaVu
 */
public class TennisGame {
	/**
	 * The total points of the server in a game.
	 */
	private int currentServerPoint;
	
	/**
	 * The total points of the receiver in a game.
	 */
	private int currentReceiverPoint;
	
	/**
	 * The direction of the ball.
	 */
	private BallDirection ballStatus;
	
	/**
	 * The number of fault the server may make.
	 */
	private int numOfFault = 0;
	
	/**
	 * Indicates whether the ball hits outside of the bounds.
	 */
	private boolean outOfBounds;
	
	public TennisGame()
	{
		currentServerPoint = 0;
		currentReceiverPoint = 0;
		ballStatus = NOT_IN_PLAY;
	}
	
	/**
	 * Directly sets the scores to the given amounts and sets the ball's status to NOT_IN_PLAY.
	 * @param newServerScore
	 * new score for the server
	 * @param newReceiverScore
	 * new score for the receiver
	 */
	public void setScore(int newServerScore, int newReceiverScore)
	{
		currentServerPoint = newServerScore;
		currentReceiverPoint = newReceiverScore;
		ballStatus = NOT_IN_PLAY;
	}

	/**
	 * Returns the current number of points for the receiver.
	 * @return
	 * current number of points for the receiver
	 */
	public int getReceiverPoints()
	{
		return currentReceiverPoint;
	}
	
	/**
	 * Returns the current number of points for the server.
	 * @return
	 * current number of points for the server
	 */
	public int getServerPoints()
	{
		return currentServerPoint;
	}
	
	/**
	 * Returns the current status of the ball (traveling toward the receiver, traveling toward the server, or not in play).
	 * @return
	 * current status of the ball
	 */
	public BallDirection getBallStatus()
	{
		return ballStatus;
	}
	
	/**
	 * Returns true if the game is over.
	 * @return
	 * true if the game is over, false otherwise
	 */
	public boolean isOver()
	{
		return ((currentServerPoint > 3 || currentReceiverPoint > 3) && (Math.abs(currentServerPoint - currentReceiverPoint) >= 2));
	}
	
	/**
	 * Returns true if the game is over and the server has won.
	 * @return
	 * true if the server has won the game, false otherwise
	 */
	public boolean serverWon()
	{
		return ((currentServerPoint > 3) && ((currentServerPoint - currentReceiverPoint) >= 2));
	}
	
	/**
	 * Returns true if the game is over and the receiver has won.
	 * @return
	 * true if the receiver has won the game, false otherwise
	 */
	public boolean receiverWon()
	{
		return ((currentReceiverPoint > 3) && ((currentReceiverPoint - currentServerPoint) >= 2));
	}
	
	/**
	 * Simulates the server serving the ball.
	 * @param serviceFault
	 * true if there is a service fault, false otherwise
	 */
	public void serve(boolean serviceFault)
	{
		if (isOver() == false && ballStatus == NOT_IN_PLAY)
		{
			if (serviceFault == false)
			{
				ballStatus = TOWARD_RECEIVER;
				numOfFault = 0;
			}
			else
			{
				numOfFault = numOfFault + 1;
				if (numOfFault >= 2)
					{
					currentReceiverPoint = currentReceiverPoint + 1;
					numOfFault = 0;
					}
			}
		}
	}
	
	/**
	 * Simulates a hit of the ball by the player toward whom the ball is currently moving.
	 * @param fault
	 * true if this hit ends the rally
	 * @param headedOutOfBounds
	 * true if the hit is not a fault but is on an out-of-bounds trajectory
	 */
	public void hit(boolean fault, boolean headedOutOfBounds)
	{
	if (ballStatus != NOT_IN_PLAY)
	{
		if (fault == true)
		{
			if (ballStatus == TOWARD_SERVER)
			{
				currentReceiverPoint = currentReceiverPoint + 1;
				ballStatus = NOT_IN_PLAY;
			}
			else
			{
				currentServerPoint = currentServerPoint + 1;
				ballStatus = NOT_IN_PLAY;
			}
		}
		else if ((headedOutOfBounds == false) && (ballStatus == TOWARD_RECEIVER))
			{
			   ballStatus = TOWARD_SERVER;
			   outOfBounds = headedOutOfBounds;
			}
		else if ((headedOutOfBounds == false) && (ballStatus == TOWARD_SERVER))
		    {
		       ballStatus = TOWARD_RECEIVER;
		       outOfBounds = headedOutOfBounds;			
		    }
		else if ((headedOutOfBounds == true) && (ballStatus == TOWARD_RECEIVER))
			{
			   ballStatus = TOWARD_SERVER;
			   outOfBounds = headedOutOfBounds;
			}
		else if ((headedOutOfBounds == true) && (ballStatus == TOWARD_SERVER))
	    {
	       ballStatus = TOWARD_RECEIVER;
	       outOfBounds = headedOutOfBounds;			
	    }
	}
	}
	
	/**
	 * Simulates a miss of the ball by the player toward whom the ball is currently traveling.
	 */
	public void miss()
	{
		if (outOfBounds == true)
		{
			if (ballStatus == TOWARD_SERVER)
			{
				currentServerPoint = currentServerPoint + 1;
				ballStatus = NOT_IN_PLAY;
				outOfBounds = false;
			}
			else if (ballStatus == TOWARD_RECEIVER)
			{
				currentReceiverPoint = currentReceiverPoint + 1;
				ballStatus = NOT_IN_PLAY;
			}
		}
		else
		{
			if (ballStatus == TOWARD_SERVER)
			{
				currentReceiverPoint = currentReceiverPoint + 1;
				ballStatus = NOT_IN_PLAY;
			}
			else if (ballStatus == TOWARD_RECEIVER)
			{
				currentServerPoint = currentServerPoint + 1;
				ballStatus = NOT_IN_PLAY;
			}
		}
	}
	
	/**
	 * Returns a string representation of the raw points for each player
	 * @return
	 * string representation of the score
	 */
	public java.lang.String getScore()
	{
		return currentServerPoint + "-" + currentReceiverPoint;
	}
	
	/**
	 * Returns a string name of the raw points.
	 * @param point
	 * the raw points a player can get.
	 * @return
	 * the tennis name of the raw points.
	 */
	private java.lang.String pointName(int point)
	{
		if (point == 0)
			{
				return "love";
			}
		else if (point == 1)
			{
				return "15";
			}
		else if (point == 2)
			{
				return "30";
			}
		else if (point == 3)
		{
			return "40";
		}
		else
			{
				return "";
			}
	}
	
	/**
	 * Returns a string representation of the score using the bizarre conventions of tennis.
	 * @return
	 * string representing the game's current score using tennis conventions
	 */
	public java.lang.String getCallString()
	{
		if (isOver())
		{
			return getScore();
		}
		else if ((currentServerPoint >= 4) && (currentServerPoint - currentReceiverPoint == 1))
		{
			return "advantage in";
		}
		else if ((currentReceiverPoint >= 4) && (currentReceiverPoint - currentServerPoint == 1))
		{
			return "advantage out";
		}
		else if ((currentServerPoint >= 3) && (currentServerPoint == currentReceiverPoint))
		{
			return "deuce";
		}
		else if ((currentServerPoint == 0) && (currentServerPoint == currentReceiverPoint))
		{
			return pointName(currentServerPoint) + "-" + "all";
		}
		else if ((currentServerPoint == 1) && (currentServerPoint == currentReceiverPoint))
		{
			return pointName(currentServerPoint) + "-" + "all";
		}
		else if ((currentServerPoint == 2) && (currentServerPoint == currentReceiverPoint))
		{
			return pointName(currentServerPoint) + "-" + "all";
		}
		else
		{
			return pointName(currentServerPoint) + "-" + pointName(currentReceiverPoint);
		}
	}
}
